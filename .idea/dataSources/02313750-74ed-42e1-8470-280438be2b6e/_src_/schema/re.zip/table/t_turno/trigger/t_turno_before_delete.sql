CREATE TRIGGER t_turno_before_delete
BEFORE DELETE ON t_turno
FOR EACH ROW
  BEGIN 
UPDATE t_version 
  SET ver=(1+ver) 
  WHERE  idv='1'; 
END;
